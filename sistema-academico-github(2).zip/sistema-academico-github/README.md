# Sistema de Gerenciamento Acadêmico

Projeto didático de Programação Web I, reunindo os conteúdos de HTML semântico, DOM, eventos, arrays/objetos, JSON e LocalStorage.

## Funcionalidades

- Dashboard com totais calculados a partir dos dados.
- Cadastro, edição, listagem e remoção de alunos, cursos, matrículas e usuários.
- Busca por nome/descrição e filtro por status nas listagens.
- Persistência local com `localStorage` e serialização com `JSON.stringify()`.
- Dados iniciais de demonstração, carregados somente quando ainda não existem dados salvos.
- Layout responsivo com CSS externo.

## Como executar

1. Extraia a pasta `sistema-academico-github`.
2. Abra `index.html` no navegador. Para uma experiência melhor, use a extensão **Live Server** do VS Code.
3. Cadastre ou edite registros. Os dados ficam salvos no navegador.
4. Para publicar, envie todos os arquivos e pastas deste projeto para um repositório GitHub.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie os arquivos mantendo a estrutura de pastas.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois salve.
6. Aguarde a publicação e abra o endereço informado pelo GitHub.

## Observações importantes

- Este é um projeto acadêmico de demonstração: não possui servidor nem banco de dados.
- O `localStorage` salva os dados somente no navegador e na origem do site em que foram cadastrados. Os dados não são compartilhados entre dispositivos ou navegadores.
- Não use dados pessoais reais, senhas ou informações sensíveis.
- Para reiniciar os dados de demonstração, abra o Console do navegador e execute:
  `localStorage.clear(); location.reload();`
- O projeto não implementa autenticação real. A área de usuários é apenas um cadastro demonstrativo.

## Estrutura

```text
sistema-academico-github/
├── index.html
├── alunos.html
├── aluno-form.html
├── cursos.html
├── curso-form.html
├── matriculas.html
├── matricula-form.html
├── usuarios.html
├── usuario-form.html
├── css/
│   └── style.css
└── js/
    ├── dados.js
    ├── storage.js
    └── app.js
```
