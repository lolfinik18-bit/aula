// Interface, renderização, formulários e eventos do Sistema Acadêmico.
const $ = (seletor) => document.querySelector(seletor);
const pagina = document.body.dataset.page;

function nomeCurso(id) {
  return cursos.find(curso => curso.id === Number(id))?.nome || "Curso não encontrado";
}
function nomeAluno(id) {
  return alunos.find(aluno => aluno.id === Number(id))?.nome || "Aluno não encontrado";
}
function statusHTML(status) {
  const classe = String(status).toLowerCase();
  return `<span class="status ${classe}">${status}</span>`;
}
function criarElemento(tag, texto, classe) {
  const el = document.createElement(tag);
  if (texto !== undefined) el.textContent = texto;
  if (classe) el.className = classe;
  return el;
}
function criarCard(titulo, linhas, editarUrl, removerAcao) {
  const article = document.createElement("article");
  article.className = "card";
  article.append(criarElemento("h3", titulo));
  linhas.forEach(linha => {
    const p = document.createElement("p");
    if (linha && linha.nodeType) p.append(linha);
    else p.textContent = linha;
    article.append(p);
  });
  const actions = criarElemento("div", undefined, "actions");
  const editar = document.createElement("a");
  editar.className = "button secondary";
  editar.href = editarUrl;
  editar.textContent = "Editar";
  const remover = document.createElement("button");
  remover.className = "danger";
  remover.type = "button";
  remover.textContent = "Remover";
  remover.addEventListener("click", removerAcao);
  actions.append(editar, remover);
  article.append(actions);
  return article;
}
function mostrarLista(container, itens) {
  container.replaceChildren();
  if (!itens.length) {
    container.append(criarElemento("p", "Nenhum registro encontrado.", "empty"));
    return;
  }
  itens.forEach(item => container.append(item));
}
function atualizarDashboard() {
  const totais = {
    alunos: alunos.length,
    cursos: cursos.length,
    matriculas: matriculas.length,
    usuarios: usuarios.length
  };
  Object.entries(totais).forEach(([chave, total]) => {
    const alvo = document.querySelector(`#total-${chave}`);
    if (alvo) alvo.textContent = total;
  });
  const ativos = {
    alunos: alunos.filter(x => x.status === "ativo").length,
    cursos: cursos.filter(x => x.status === "ativo").length,
    matriculas: matriculas.filter(x => x.status === "ativa").length,
    usuarios: usuarios.filter(x => x.status === "ativo").length
  };
  Object.entries(ativos).forEach(([chave, total]) => {
    const alvo = document.querySelector(`#ativos-${chave}`);
    if (alvo) alvo.textContent = total;
  });
}
function salvarEAtualizar() {
  persistirTudo();
  atualizarDashboard();
}
function preencherSelectCursos(select, selecionado) {
  if (!select) return;
  select.replaceChildren();
  cursos.forEach(curso => {
    const option = document.createElement("option");
    option.value = curso.id;
    option.textContent = `${curso.sigla} — ${curso.nome}`;
    if (Number(selecionado) === curso.id) option.selected = true;
    select.append(option);
  });
}
function preencherSelectAlunos(select, selecionado) {
  if (!select) return;
  select.replaceChildren();
  alunos.forEach(aluno => {
    const option = document.createElement("option");
    option.value = aluno.id;
    option.textContent = aluno.nome;
    if (Number(selecionado) === aluno.id) option.selected = true;
    select.append(option);
  });
}
function idDaUrl() {
  return Number(new URLSearchParams(location.search).get("id")) || null;
}
function prepararFormulario(tipo, lista, campos, montarObjeto) {
  const form = $("#registro-form");
  if (!form) return;
  const id = idDaUrl();
  const existente = id ? lista.find(item => item.id === id) : null;
  if (id && !existente) {
    $("#form-mensagem").textContent = "Registro não encontrado.";
    form.querySelector("button[type=submit]").disabled = true;
    return;
  }
  if (existente) {
    $("#form-titulo").textContent = `Editar ${tipo}`;
    campos.forEach(campo => {
      const input = form.elements[campo];
      if (input) input.value = existente[campo] ?? "";
    });
    if (tipo === "aluno") preencherSelectCursos(form.elements.cursoId, existente.cursoId);
    if (tipo === "matricula") {
      preencherSelectAlunos(form.elements.alunoId, existente.alunoId);
      preencherSelectCursos(form.elements.cursoId, existente.cursoId);
    }
  } else {
    if (tipo === "aluno") preencherSelectCursos(form.elements.cursoId);
    if (tipo === "matricula") {
      preencherSelectAlunos(form.elements.alunoId);
      preencherSelectCursos(form.elements.cursoId);
    }
  }
  form.addEventListener("submit", event => {
    event.preventDefault();
    const dados = montarObjeto(form);
    if (existente) Object.assign(existente, dados);
    else lista.push({ id: proximoId(lista), ...dados });
    salvarEAtualizar();
    location.href = `${tipo === "aluno" ? "alunos" : tipo === "curso" ? "cursos" : tipo === "matricula" ? "matriculas" : "usuarios"}.html`;
  });
}
function renderizarAlunos() {
  const container = $("#lista-alunos");
  if (!container) return;
  const busca = ($("#busca")?.value || "").trim().toLowerCase();
  const status = $("#filtro-status")?.value || "";
  const filtrados = alunos.filter(aluno =>
    aluno.nome.toLowerCase().includes(busca) &&
    (!status || aluno.status === status)
  );
  mostrarLista(container, filtrados.map(aluno => criarCard(
    aluno.nome,
    [`E-mail: ${aluno.email}`, `Curso: ${nomeCurso(aluno.cursoId)}`, `Status: ${aluno.status}`],
    `aluno-form.html?id=${aluno.id}`,
    () => {
      if (!confirm(`Remover o aluno ${aluno.nome}?`)) return;
      alunos = alunos.filter(item => item.id !== aluno.id);
      matriculas = matriculas.filter(item => item.alunoId !== aluno.id);
      salvarEAtualizar(); renderizarAlunos();
    }
  )));
}
function renderizarCursos() {
  const container = $("#lista-cursos");
  if (!container) return;
  const busca = ($("#busca")?.value || "").trim().toLowerCase();
  const status = $("#filtro-status")?.value || "";
  const filtrados = cursos.filter(curso =>
    `${curso.sigla} ${curso.nome}`.toLowerCase().includes(busca) &&
    (!status || curso.status === status)
  );
  mostrarLista(container, filtrados.map(curso => criarCard(
    `${curso.sigla} — ${curso.nome}`,
    [`Status: ${curso.status}`],
    `curso-form.html?id=${curso.id}`,
    () => {
      if (!confirm(`Remover o curso ${curso.sigla}?`)) return;
      cursos = cursos.filter(item => item.id !== curso.id);
      salvarEAtualizar(); renderizarCursos();
    }
  )));
}
function renderizarMatriculas() {
  const container = $("#lista-matriculas");
  if (!container) return;
  const busca = ($("#busca")?.value || "").trim().toLowerCase();
  const status = $("#filtro-status")?.value || "";
  const filtrados = matriculas.filter(m => {
    const texto = `${m.numero} ${nomeAluno(m.alunoId)} ${nomeCurso(m.cursoId)}`.toLowerCase();
    return texto.includes(busca) && (!status || m.status === status);
  });
  mostrarLista(container, filtrados.map(m => criarCard(
    `Matrícula ${m.numero}`,
    [`Aluno: ${nomeAluno(m.alunoId)}`, `Curso: ${nomeCurso(m.cursoId)}`, `Status: ${m.status}`],
    `matricula-form.html?id=${m.id}`,
    () => {
      if (!confirm(`Remover a matrícula ${m.numero}?`)) return;
      matriculas = matriculas.filter(item => item.id !== m.id);
      salvarEAtualizar(); renderizarMatriculas();
    }
  )));
}
function renderizarUsuarios() {
  const container = $("#lista-usuarios");
  if (!container) return;
  const busca = ($("#busca")?.value || "").trim().toLowerCase();
  const status = $("#filtro-status")?.value || "";
  const filtrados = usuarios.filter(u =>
    `${u.nome} ${u.email} ${u.perfil}`.toLowerCase().includes(busca) &&
    (!status || u.status === status)
  );
  mostrarLista(container, filtrados.map(u => criarCard(
    u.nome,
    [`E-mail: ${u.email}`, `Perfil: ${u.perfil}`, `Status: ${u.status}`],
    `usuario-form.html?id=${u.id}`,
    () => {
      if (!confirm(`Remover o usuário ${u.nome}?`)) return;
      usuarios = usuarios.filter(item => item.id !== u.id);
      salvarEAtualizar(); renderizarUsuarios();
    }
  )));
}

function iniciar() {
  atualizarDashboard();
  const rotinas = {
    alunos: renderizarAlunos,
    cursos: renderizarCursos,
    matriculas: renderizarMatriculas,
    usuarios: renderizarUsuarios
  };
  if (rotinas[pagina]) {
    rotinas[pagina]();
    $("#busca")?.addEventListener("input", rotinas[pagina]);
    $("#filtro-status")?.addEventListener("change", rotinas[pagina]);
  }

  if (pagina === "aluno-form") prepararFormulario("aluno", alunos,
    ["nome", "email", "cursoId", "status"], form => ({
      nome: form.elements.nome.value.trim(),
      email: form.elements.email.value.trim(),
      cursoId: Number(form.elements.cursoId.value),
      status: form.elements.status.value
    }));
  if (pagina === "curso-form") prepararFormulario("curso", cursos,
    ["sigla", "nome", "status"], form => ({
      sigla: form.elements.sigla.value.trim().toUpperCase(),
      nome: form.elements.nome.value.trim(),
      status: form.elements.status.value
    }));
  if (pagina === "matricula-form") prepararFormulario("matricula", matriculas,
    ["numero", "alunoId", "cursoId", "status"], form => ({
      numero: form.elements.numero.value.trim(),
      alunoId: Number(form.elements.alunoId.value),
      cursoId: Number(form.elements.cursoId.value),
      status: form.elements.status.value
    }));
  if (pagina === "usuario-form") prepararFormulario("usuario", usuarios,
    ["nome", "email", "perfil", "status"], form => ({
      nome: form.elements.nome.value.trim(),
      email: form.elements.email.value.trim(),
      perfil: form.elements.perfil.value,
      status: form.elements.status.value
    }));
  document.querySelectorAll("form").forEach(form => {
    form.addEventListener("input", () => {
      const mensagem = $("#form-mensagem");
      if (mensagem) mensagem.textContent = "";
    });
  });
}
document.addEventListener("DOMContentLoaded", iniciar);
