// Dados demonstrativos da aplicação. Não inclua informações pessoais reais.
const dadosIniciais = {
  alunos: [
    { id: 1, nome: "Ana Souza", email: "ana.exemplo@email.com", cursoId: 1, status: "ativo" },
    { id: 2, nome: "Carlos Silva", email: "carlos.exemplo@email.com", cursoId: 2, status: "ativo" },
    { id: 3, nome: "Mariany Santos", email: "mariany.exemplo@email.com", cursoId: 1, status: "inativo" }
  ],
  cursos: [
    { id: 1, sigla: "ADS", nome: "Análise e Desenvolvimento de Sistemas", status: "ativo" },
    { id: 2, sigla: "CC", nome: "Ciência da Computação", status: "ativo" },
    { id: 3, sigla: "ES", nome: "Engenharia de Software", status: "ativo" }
  ],
  matriculas: [
    { id: 1, numero: "2026001", alunoId: 1, cursoId: 1, status: "ativa" },
    { id: 2, numero: "2026002", alunoId: 2, cursoId: 2, status: "ativa" }
  ],
  usuarios: [
    { id: 1, nome: "Administrador", email: "admin@exemplo.edu", perfil: "Administrador", status: "ativo" },
    { id: 2, nome: "Secretaria Acadêmica", email: "secretaria@exemplo.edu", perfil: "Secretaria", status: "ativo" },
    { id: 3, nome: "Usuário Consulta", email: "consulta@exemplo.edu", perfil: "Consulta", status: "inativo" }
  ]
};
