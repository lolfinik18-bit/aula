// Camada de persistência: transforma arrays/objetos em JSON e salva no LocalStorage.
const STORAGE_KEYS = {
  alunos: "academico_alunos",
  cursos: "academico_cursos",
  matriculas: "academico_matriculas",
  usuarios: "academico_usuarios"
};

function carregarDados(chave, valorPadrao) {
  const texto = localStorage.getItem(chave);
  if (!texto) return JSON.parse(JSON.stringify(valorPadrao));
  try {
    return JSON.parse(texto);
  } catch (erro) {
    console.error("Não foi possível interpretar os dados salvos:", erro);
    return JSON.parse(JSON.stringify(valorPadrao));
  }
}

function salvarDados(chave, dados) {
  localStorage.setItem(chave, JSON.stringify(dados));
}

let alunos = carregarDados(STORAGE_KEYS.alunos, dadosIniciais.alunos);
let cursos = carregarDados(STORAGE_KEYS.cursos, dadosIniciais.cursos);
let matriculas = carregarDados(STORAGE_KEYS.matriculas, dadosIniciais.matriculas);
let usuarios = carregarDados(STORAGE_KEYS.usuarios, dadosIniciais.usuarios);

function persistirTudo() {
  salvarDados(STORAGE_KEYS.alunos, alunos);
  salvarDados(STORAGE_KEYS.cursos, cursos);
  salvarDados(STORAGE_KEYS.matriculas, matriculas);
  salvarDados(STORAGE_KEYS.usuarios, usuarios);
}

function proximoId(lista) {
  return lista.length ? Math.max(...lista.map(item => Number(item.id) || 0)) + 1 : 1;
}
